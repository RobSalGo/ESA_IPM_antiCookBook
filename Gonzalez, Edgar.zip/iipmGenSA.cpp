// TITLE: Inferring structured vital rates from limited information: an integrated integral projection model
// DATE: 31 May 2015
// AUTHOR: Edgar J. González (edgarjgonzalez@ymail.com)

// Libraries used
# include <Rcpp.h> 
# include <math.h> /* for fabs, pow, log, exp, erf functions*/
# include <cmath>

using namespace Rcpp;

// FUNCTION invipm

// INPUT
// xpars: parameters of the model (S0-beta9)
// xn_i: bin size of the matrix used to approximate the kernel
// xx_minf: size of smallest reproductive individual
// xw: w in the composite likelihood
// xD: time series of population sizes as a n_t x 2 matrix (1st column = observed times [this can be sparsely distributed], 2nd column = population sizes)
// xmax_scale_x: maximum individual size
// xmin_scale_x: minimum individual size
// xfreq_i_t: time series of population structures as a n_i x n_t matrix (n_t = length of time series)
// xa1, xb1, xa2: constants associated to the orthogonal transformation of the sizes in the survival function

// OUTPUT
// v: composite likelihood

// [[Rcpp::export]]
NumericVector invipm(NumericVector xpars, NumericVector xn_i, NumericVector xx_minf, NumericVector xw, NumericMatrix xD, NumericVector xmax_scale_x, NumericVector xmin_scale_x, NumericMatrix xfreq_i_t, NumericVector xa1, NumericVector xb1, NumericVector xa2) 
{
	// declaration of variables
	int n_i = Rcpp::as<int>(xn_i);
	float x_minf = Rcpp::as<float>(xx_minf);
	float w = Rcpp::as<float>(xw);
	int n_t = xD.nrow();
	float D[n_t][2];
	int i,j,k,l,ti,tj;
	int minf_i;
	int t[n_t];
	int n_pars = xpars.size();
	float pars[n_pars];
	for(i = 0; i < n_t; i++)
		for(j = 0; j < 2; j++)
			D[i][j] = xD(i,j); 
	for(i = 0; i < xpars.size(); i++)
		pars[i] = xpars(i);
	float max_scale_x = Rcpp::as<float>(xmax_scale_x);
	float min_scale_x = Rcpp::as<float>(xmin_scale_x);	
	float S0 = pars[0];
	float S1 = pars[1];
	float S2 = pars[2];
	float beta3 = pars[3];
	float beta4 = pars[4];
	float beta5 = pars[5];
	float beta6 = pars[6];
	float beta7 = pars[7];
	float beta8 = pars[8];
	float beta9 = pars[9];
	float v_t;
	float a1;
	a1 = Rcpp::as<float>(xa1);
	float a2;
	a2 = Rcpp::as<float>(xa2);
	float alpha0;
	float alpha1;
	float alpha2;
	float b;
	float b1;
	b1 = Rcpp::as<float>(xb1);
	float c;
	float d;
	float d_temp;
	float eu;
	float inc;
	float lambda;
	float max_x;
	float min_x;
	float ns_mu;
	float beta0;
	float beta1;
	float beta2;
	float scale_x_minf;
	float temp;
	float u;
	float v_N;
	float v_n;
	float y;
	float d_est[1000]; // increase if max(t)-min(t) > 1000
	float d_t[n_t];
	float d_t_est[n_t-1];
	float f_j[n_i];
	float g_j[n_i];
	float g_mu[n_i];
	float inex[n_i];
	float f_i[n_i];
	float ns_j[n_i];
	float p_j[n_i];
	float s_i[n_i];
	float x_i[n_i];
	float z_i[n_i+1];
	float z_g[n_i+1];
	float z_ns[n_i+1];
	float freq_i_t[n_i][n_t];
	for(i = 0; i < n_i; i++)
		for(j = 0; j < n_t; j++)
			freq_i_t[i][j] = xfreq_i_t(i,j);
	float n_i_t[n_i][n_t-1];
	float k_ij[n_i][n_i];
	for(i = 0; i < n_t; i++)
		t[i] = D[i][0];		
	int mint = t[0];
	for(i = 1; i < n_t; i++)
	{
		if(t[i] < mint)
			mint = t[i];
	}	
	for(i = 0; i < n_t; i++)		
		t[i] = t[i]-mint;	
	for(i = 0; i < n_t; i++)
		d_t[i] = D[i][1];	
	scale_x_minf = x_minf;
	min_x = min_scale_x;
	max_x = max_scale_x;
	// binning
	inc = (max_x-min_x)/n_i;
	x_i[0] = min_x+inc/2.0;
	z_i[0] = min_x;
	z_i[1] = z_i[0]+inc;
	for(i = 1; i < n_i; i++)
		{
		x_i[i] = x_i[i-1]+inc;
		z_i[i+1] = z_i[i]+inc;
		}
	if(scale_x_minf >= z_i[0] && scale_x_minf <= z_i[1])
		minf_i = 1;
	for(i = 0; i < n_i; i++)
		if(scale_x_minf > z_i[i] && scale_x_minf <= z_i[i+1])
			minf_i = i;
	b = 1.0e+2;
	c = 1.0e+2;
	d = 13.0/6.0;
	// parameter transformation to describe survival as logistic(survival) = beta0+beta1*size+beta2*size^2
	alpha0 = S0-2.0*S1*a1+4.0*S2*a1*a2-S2*b1;
	alpha1 = 2.0*S1-4.0*S2*a1-4.0*S2*a2;
	alpha2 = 4.0*S2;
	beta0 = alpha0-alpha1*(max_x+min_x)/(max_x-min_x)+alpha2*pow(max_x+min_x,2.0)/pow(max_x-min_x,2.0);
	beta1 = 2.0*alpha1/(max_x-min_x)-4.0*alpha2*(max_x+min_x)/pow(max_x-min_x,2.0);
	beta2 = 4.0*alpha2/pow(max_x-min_x,2.0);	
	// kernel construction
	d_temp = d_t[0];
	d_est[0] = d_t[0];
	for(i = 0; i < n_i; i++)
		inex[i] = freq_i_t[i][0];
	float sum_inex = inex[0];
	for(i = 1; i < n_i; i++)
		sum_inex += inex[i];
	for(i = 0; i < n_i; i++)
		inex[i] = inex[i]/sum_inex;
	j = t[0];
	for(k = 0; k < n_i; k++)
		{
		u = -beta0-beta1*x_i[k]-beta2*pow(x_i[k],2.0);
		if(u <= b && u >= -c)
			eu = exp(u);
		else
			{
			if(u > b)
				eu = exp(b)*(1.0+(u-b)/(1.0+u-b)*(1.0+(u-b)/(1.0+u-b)*(1.5+d*(u-b)/(1.0+u-b))));
			else
				eu = exp(-c)/(1.0+(-u-c)/(1.0-u-c)*(1.0+(-u-c)/(1.0-u-c)*(1.5+d*(-u-c)/(1.0-u-c))));
			}
		s_i[k] = 1.0/(1.0+eu);
		}
	for(k = 0; k < n_i; k++)
		f_i[k] = 0.0;
	for(k = minf_i; k <= n_i; k++)
		{
		u = beta6+beta7*x_i[k];
		if(u <= b && u >= -c)
			eu = exp(u);
		else
			{
			if(u > b)
   	  			eu = exp(b)*(1.0+(u-b)/(1.0+u-b)*(1.0+(u-b)/(1.0+u-b)*(1.5+d*(u-b)/(1.0+u-b)))); 
   	  		else 
   	  			eu = exp(-c)/(1.0+(-u-c)/(1.0-u-c)*(1.0+(-u-c)/(1.0-u-c)*(1.5+d*(-u-c)/(1.0-u-c))));
   	  		}
   	  	f_i[k] = eu;
   	  	}
   	ns_mu = beta8;
	for(k = 0; k <= n_i; k++)
		z_ns[k] = (z_i[k]-ns_mu)/pow(10.0,beta9);
	ns_j[0] = 0.5*(1.0+erf(z_ns[1]/sqrt(2.0)));
	ns_j[n_i-1] = 1.0-0.5*(1.0+erf(z_ns[n_i-1]/sqrt(2.0)));
	for(k = 1; k < (n_i-1); k++)
		ns_j[k] = 0.5*(1.0+erf(z_ns[k+1]/sqrt(2.0)))-0.5*(1.0+erf(z_ns[k]/sqrt(2.0)));
	float g_ij[n_i][n_i];
	for(k = 0; k < n_i; k++)
	{
	 	g_mu[k] = beta3+beta4*x_i[k];
	 	for(l = 0; l <= n_i; l++)
	 		z_g[l] = (z_i[l]-g_mu[k])/pow(10.0,beta5);
	 	g_j[0] = 0.5*(1.0+erf(z_g[1]/sqrt(2.0)));
	 	g_j[n_i-1] = 1.0-0.5*(1.0+erf(z_g[n_i-1]/sqrt(2.0)));
	 	for(l = 1; l < (n_i-1); l++)
	 		g_j[l] = 0.5*(1.0+erf(z_g[l+1]/sqrt(2.0)))-0.5*(1.0+erf(z_g[l]/sqrt(2.0)));
	 	for(l = 0; l < n_i; l++)
		{
			g_ij[l][k] = g_j[l];
		 	p_j[l] = s_i[k]*g_j[l];
		 	f_j[l] = f_i[k]*ns_j[l];
	 		k_ij[l][k] = p_j[l]+f_j[l];
		}
	 }
	// IProjM iteration
	float inex1[n_i];
	for(i = 0; i < n_t-1; i++)
	 	{
	 	ti = t[i];
	 	tj = t[i+1];
	 	for(j = ti; j < tj; j++)
	 		{
			for(k = 0; k < n_i; k++)	
			{
				inex1[k] = 0.0;
				for(l = 0; l < n_i; l++)
					inex1[k] += k_ij[k][l]*inex[l];
			}
			for(k = 0; k < n_i; k++)
				inex[k] = inex1[k];
			lambda = 0.0;
			for(k = 0; k < n_i; k++)
				lambda += inex[k];
	 		d_temp = lambda*d_temp;
	 		d_est[j+1] = d_temp;
			for(k = 0; k < n_i; k++)
				inex[k] = inex[k]/lambda;
	 		}
	 	d_t_est[i] = d_temp;
	 	for(j = 0; j < n_i; j++)
		{
			n_i_t[j][i] = inex[j];
		}
	 	for(k = 0; k < n_i; k++)
	 		if(n_i_t[k][i] < 0.001)
	 			{
	 			y = 0.001-n_i_t[k][i];
	 			temp = y/0.001;
	 			n_i_t[k][i] = 0.001/(1.0+temp+pow(temp,2.0)+pow(temp,3.0));
	 			}
	 	}
	// likelihood associated to population sizes
	v_N = 0.0;
	for(i = 0; i < (n_t-1); i++)
		v_N += pow(log(d_t[i+1])-log(d_t_est[i]),2.0);
	v_N = log(sqrt(v_N));
	// likelihood associated to population structures
	v_n = 0.0;
	for(i = 1; i < n_t; i++)
		for(j = 0; j < n_i; j++)
			v_n += freq_i_t[j][i]*log(n_i_t[j][i-1]);
	v_t = -w*v_n+(1.0-w)*v_N;
	Rcout << std::endl;
	Rcout << "beta0 = " << beta0 << std::endl;
	Rcout << "beta1 = " << beta1 << std::endl;
	Rcout << "beta2 = " << beta2 << std::endl;
	Rcout << "beta3 = " << beta3 << std::endl;
	Rcout << "beta4 = " << beta4 << std::endl;
	Rcout << "beta5 = " << beta5 << std::endl;
	Rcout << "beta6 = " << beta6 << std::endl;
	Rcout << "beta7 = " << beta7 << std::endl;
	Rcout << "beta8 = " << beta8 << std::endl;
	Rcout << "beta9 = " << beta9 << std::endl;
	Rcout << "size log-l = " << v_n << std::endl;
	Rcout << "structure log-l = " << v_N << std::endl;
	Rcout << "composite log-l = " << -v_t << std::endl;
	Rcout << std::endl;
	NumericVector v;
	return v = v_t;
}
