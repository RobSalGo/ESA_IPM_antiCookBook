### PAPER TITLE: Inferring structured vital rates from limited information: an integrated integral projection model
### DATE: 31 May 2015
### AUTHOR: Edgar J. González (edgarjgonzalez@ymail.com)

## DESCRIPTION: This code estimates unobserved structured vital rates using as input a time series of population structures and sizes.
# Known vital rates can be incorporated by placing the corresponding parameter values in the "known" column in the intervals.csv file and putting a -1 in the corresponding parameter in the PARAMETER_SECTION of the iipmADMB.tpl file.

## INPUT
## iipmADMB.dat: contains the time series (see the section: Reading the infor mation contained in the .dat file)
## iipmADMB.tpl: contains the code required by ADMB to calculate the composite negative log-likelihood
## iipmGenSA.cpp: contains the code required by GenSA to calculate the composite negative log-likelihood
## intervals.csv: contains the parameter values used to generate the data and the parameter intervals determining the hypercube of possible parameter values
## pins.csv: contains the 100 random starting points used in the Methods section

## OUTPUT
## estimates: a warning is printed if the estimates reached a parameter bound 
## composite.ll: composite log-likelihood associated to the estimates
## hessian: if NULL the model reached a flat region

library(GenSA)
library(lhs)
library(R2admb)
library(Rcpp)

## Set working directory
# setwd("...") 

## Number of parameters
# this number can't be changed
n.p <- 10

## Parameter names
par.names <- paste("beta", seq(0, n.p-1), sep = "")

## Hypercube limits
conf.int <- read.csv("intervals.csv", header = T)
hyper.min <- conf.int$hyper.min
hyper.max <- conf.int$hyper.max

## Parameter values used to generate the data
known <- conf.int$known

## Identifying the parameters for  which their values are fixed (i.e. we don't want to estimate)
# the fixed parameters have a -1 in the PARAMETER SECTION of the .tpl file
tpl <- readLines("iipmADMB.tpl")
tpl <- tpl[grep("PARAMETER_SECTION", tpl):grep("objective_function_value", tpl)]
fixed <- c()
for (i in 1:n.p) {
  line.declare <- tpl[grep(par.names[i], tpl)[1]]
  if (grepl("-1)", line.declare, fixed = T))
    fixed <- c(fixed, i)	
}

if (file.exists("pins.csv")) {
  pins <- read.csv("pins.csv", header = F, sep = " ")
  h <- dim(pins)[1]
}

## Generating h random starting points
# ATTENTION: the model will run with the starting points provided in pins.csv. If you want to generate new random starting points delete the pins.csv file
if (!file.exists("pins.csv")) {
  h <- 100
  pins <- matrix(NA, h, n.p)
  des <- geneticLHS(h, n.p)
  for (i in 1:n.p)
    pins[, i] <- hyper.min[i]+(hyper.max[i]-hyper.min[i])*des[, i]
  for (i in fixed)	
    pins[, i] <- pin[i]		
  write.table(pins, "pins.csv", row.names = F, col.names = F)  # a .csv is generated with the starting points
}

## We take the first of this starting points
# a for loop would allow running all in sequence
i <- 1  # we can change this number to run the different starting points
init <- unname(unlist(pins[i,]))

## Reading the infor mation contained in the .dat file
data <- read.table("iipmADMB.dat", header = F)
n.t <- data[1, 1]  # time series length
n.x <- data[2, 1]  # maximum per-year sample size (note that zeros are imputed in order to have an n.x x n.t matrix)
n.i <- data[3, 1]  # binning size
x.minf <- data[4, 1]  # size of smallest reproductive individual
w <- data[5, 1]  # w in the composite likelihood
t <- as.vector(data[seq(5+1, 5+2*n.t, 2), 1])  # observed times in the time series
d.t <- as.vector(data[seq(6+1, 6+2*n.t, 2), 1])  # population sizes at each observed time
D <- cbind(t, d.t)
X <- cbind(data[seq(6+2*n.t, dim(data)[1], 2), 1], 
  data[seq(7+2*n.t, dim(data)[1], 2), 1])  # individual measuments at each time
x <- X[, 2]
X[, 1] <- X[, 1]-min(t)
t <- t-min(t)
scale.x <- x
x.p <- (2*scale.x-max(scale.x)-min(scale.x))/(max(scale.x)-min(scale.x))
a1 <- sum(x.p)/n.x
phi1 <- 2*(x.p-a1)
b1 <- sum(phi1^2)/n.x
a2 <- sum(x.p*phi1^2)/sum(phi1^2)
Mx <- max(scale.x)
mx <- min(scale.x)
min.x <- mx
max.x <- Mx
n.x.t <- rep(0, n.t)
x.t <- matrix(nrow = n.x, ncol = n.t)
for (j in 1:n.t)
  for (k in 1:n.x)
    if (X[k, 1] == t[j]) {
      n.x.t[j] <- n.x.t[j]+1
      l <- round(n.x.t[j])
      x.t[l, j] <- scale.x[k]
    }

## Generating the time series of population structures from the individual measurements contained in the .dat file
freq.i.t <- matrix(nrow = n.i, ncol = n.t)
inc <- (max.x-min.x)/n.i
x.i <- rep(0, n.i)
z.i <- rep(0, n.i+1)
x.i[1] <- min.x+inc/2
z.i[1] <- min.x
z.i[2] <- z.i[1]+inc
for (j in 2:n.i) {
  x.i[j] <- x.i[j-1]+inc
  z.i[j+1] <- z.i[j]+inc
}
for (j in 1:n.t)
  for (k in 1:n.i)
    freq.i.t[k, j] <- 0
for (j in 1:n.t)
  for (k in 1:n.x.t[j]) {
    if (x.t[k, j] >= z.i[1] & x.t[k, j] <= z.i[2])
      freq.i.t[1, j] <- freq.i.t[1, j] + 1
    for (l in 2:n.i)
      if (x.t[k, j] > z.i[l] & x.t[k, j] <= z.i[l+1])
        freq.i.t[l, j] <- freq.i.t[l, j] + 1
	}

## Transforming the iipmGenSA.cpp C code into an R function
sourceCpp("iipmGenSA.cpp")

invipm1 <- function(pars) {
  # R function when all parameters are estimated
  ll <- invipm(pars, n.i, x.minf, w, D, Mx, mx, freq.i.t, a1, b1, a2)
  invipm1 <- ll
}
invipm2 <- function(pars) {
  # R function when some parameters are fixed
  pars1 <- rep(0, n.p)
  pars1[fixed] <- known[fixed]
  pars1[-fixed] <- pars
  ll <- invipm(pars1, n.i, x.minf, w, D, Mx, mx, freq.i.t, a1, b1, a2)
  invipm2 <- ll
}

## Run the heuristic part of the algorithm (GenSA)
temp <- 1e5  # starting temperature
it <- 1e6  # maximum number of iterations
max.t <- 2700  # maximum running time
# version when all parameters are estimated
if (length(fixed) == 0)
  run <- GenSA(par = init, fn = invipm1, lower = hyper.min, upper = hyper.max, 
		control = list(temperature = temp, maxit = it, max.time = max.t))
# version when some parameters are fixed
if (length(fixed) > 0) {
  run <- GenSA(par = init[-fixed], fn = invipm2, lower = hyper.min[-fixed], 
    upper = hyper.max[-fixed], control = list(temperature = temp, maxit = it, 
    max.time = max.t))
  pin <- rep(0, n.p)
  pin[fixed] <- known[fixed]
  pin[-fixed] <- run$par
}
write.table(run$par, "iipmADMB.pin", row.names = F, col.names = F)	

## Run the gradient-based part of the algorithm (ADMB)
# admb must be installed in your computer
setup_admb("/Applications/ADMBTerminal.app/admb")  # location of the admb software
compile_admb("iipmADMB", verbose = T)
run_admb("iipmADMB", verbose = T)
# run with option profile = T to run likelihood profiling
# run with option mcmc = T to run mcmc

## Reading and printing output
output = read_admb("iipmADMB")
estimates = output$coefficients
x.p = (2*x.i-Mx-mx)/(Mx-mx)
a1 = sum(x.p)/n.i
phi1 = 2*(x.p-a1)
b1 = sum(phi1^2)/n.i
a2 = sum(x.p*phi1^2)/sum(phi1^2)
alpha0 = estimates[1]-2*estimates[2]*a1+4*estimates[3]*a1*a2-estimates[3]*b1
alpha1 = 2*estimates[2]-4*estimates[3]*a1-4*estimates[3]*a2
alpha2 = 4*estimates[3]
thresholds = (hyper.max-hyper.min)/1000
for(i in 1:3)
  if(abs(estimates[i]-hyper.min[i]) < thresholds[i] | abs(estimates[i]-hyper.max[i]) < thresholds[i])
    warning(paste("S",i-1," reached a bound",sep = ""))
for(i in 4:n.p)
  if(abs(estimates[i]-hyper.min[i]) < thresholds[i] | abs(estimates[i]-hyper.max[i]) < thresholds[i])
    warning(paste("beta",i-1," reached a bound",sep = ""))
estimates[1] = alpha0-alpha1*(Mx+mx)/(Mx-mx)+alpha2*(Mx+mx)^2/(Mx-mx)^2
estimates[2] = 2*alpha1/(Mx-mx)-4*alpha2*(Mx+mx)/(Mx-mx)^2
estimates[3] = 4*alpha2/(Mx-mx)^2
names(estimates)[1:3] = paste("beta", seq(0, 2), sep = "")
estimates  # parameter estimates
(composite.ll = -output$loglik)  # composite log-likelihood associated to the estimates
(hessian = output$hes)  # if NULL the model reached a flat region
